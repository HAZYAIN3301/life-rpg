'use strict';

importScripts('core.js', 'protection.js', 'protection-catalog.js', 'adult-list.js', 'health.js', 'puzzle-core.js', 'puzzles.js');

const Core = self.SatoruAttentionCore;
const Protection = self.SatoruProtection;
const ProtectionCatalog = self.SatoruProtectionCatalog;
const Health = self.SatoruAttentionHealth;
const PuzzleCore = self.SatoruPuzzleCore;
const Puzzles = self.SatoruPuzzles;
// The pending solution lives only in session storage (trusted contexts): the gate page never
// receives the remaining moves, so a solve cannot be faked from the page.
const PUZZLE_KEY = 'satoruPendingPuzzleV1';
const SELF_TEST_KEY = 'satoruBoundaryTestV1';
const STATE_KEY = 'satoruAttentionStateV1';
const PROTECTION_KEY = 'satoruProtectionStateV1';
const BOUNDARY_ALARM = 'satoru-attention-boundary';
const RECOVERY_ALARM = 'satoru-attention-recovery';
const PROTECTION_ALARM = 'satoru-protection-schedule';
const LOCK_ALARM = 'satoru-protection-lock';
const SITE_SCRIPT_PREFIX = 'satoru-site-';
const REDDIT_GUARD_ID = 'satoru-guard-reddit';
const RULE_BASE = 20_000;
const CLOCK_OBSERVE_INTERVAL_MS = 30_000;
const EXTENSION_ROOT = chrome.runtime.getURL('');
const attemptsByTab = new Map(); // Ephemeral only: never persisted or synced.
let mutationQueue = Promise.resolve();

function currentIso() { return new Date().toISOString(); }
function extensionSender(sender) {
  if (!sender) return false;
  const candidateUrls = [sender.url, sender.documentUrl, sender.tab && sender.tab.url];
  const extensionUrl = candidateUrls.some((url) => typeof url === 'string' && url.startsWith(EXTENSION_ROOT));
  const extensionOrigin = typeof sender.origin === 'string' && `${sender.origin}/` === EXTENSION_ROOT;
  // Brave can move an extension-page URL from `sender.url` to `sender.tab.url`.
  // Requiring both our extension ID and our extension URL keeps site content scripts out.
  return sender.id === chrome.runtime.id && (extensionUrl || extensionOrigin);
}
function bridgeSender(sender) {
  return !!(sender && typeof sender.url === 'string'
    && Core.SATORU_ORIGINS.some((origin) => sender.url === origin || sender.url.startsWith(`${origin}/`)));
}

async function loadState() {
  const stored = await chrome.storage.local.get(STATE_KEY);
  const normalized = Core.normalizeState(stored[STATE_KEY]);
  const activated = Core.activatePendingPolicies(normalized, currentIso());
  if (activated.changed) {
    await chrome.storage.local.set({ [STATE_KEY]: activated.state });
    await reconcileEnforcement(activated.state);
  }
  return activated.state;
}

async function saveState(state) {
  const normalized = Core.normalizeState(state);
  await chrome.storage.local.set({ [STATE_KEY]: normalized });
  return normalized;
}

async function loadProtection() {
  const stored = await chrome.storage.local.get(PROTECTION_KEY);
  return Protection.normalizeSettings(stored[PROTECTION_KEY]);
}

// 0.9.0 lock: credit elapsed time (at most 12 h per observation) and persist the result.
async function loadObservedProtection() {
  const stored = await loadProtection();
  const observed = Protection.observeLock(stored, new Date());
  if (JSON.stringify(observed.lock) === JSON.stringify(stored.lock)) return stored;
  return saveProtection(observed);
}

async function scheduleLockAlarm(settings) {
  if (Protection.lockActive(settings)) await chrome.alarms.create(LOCK_ALARM, { periodInMinutes: 30 });
  else await chrome.alarms.clear(LOCK_ALARM);
}

async function saveProtection(settings) {
  const normalized = Protection.normalizeSettings(settings);
  await chrome.storage.local.set({ [PROTECTION_KEY]: normalized });
  return normalized;
}

async function scheduleRecovery() {
  try { await chrome.alarms.create(RECOVERY_ALARM, { when: Date.now() + 1_000 }); }
  catch { /* The next extension event also reconciles from local state. */ }
}

async function observeClockState(at) {
  const state = await loadState();
  if (Core.clockRolledBack(state, at)) return state;
  const last = state.lastSeenAt ? Date.parse(state.lastSeenAt) : 0;
  if (!last || Date.parse(at) - last >= CLOCK_OBSERVE_INTERVAL_MS) return saveState(Core.touchClock(state, at));
  return state;
}

function serialized(work) {
  const run = mutationQueue.then(work, work);
  mutationQueue = run.catch(() => undefined);
  return run;
}

async function permissionFor(policy) {
  if (!policy) return false;
  try { return await chrome.permissions.contains({ origins: Core.hostPatterns(policy.hostname) }); }
  catch { return false; }
}

function gateUrl(policyId) {
  const id = typeof policyId === 'string' && /^[a-z0-9_-]{1,48}$/i.test(policyId) ? policyId : '';
  return chrome.runtime.getURL(`gate.html${id ? `?site=${encodeURIComponent(id)}` : ''}`);
}

function protectionUrl() {
  return chrome.runtime.getURL('block.html');
}

async function broadProtectionPermission() {
  try {
    return await chrome.permissions.contains({ origins: ['http://*/*', 'https://*/*'] });
  } catch { return false; }
}

function localDayKey() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function nextLocalMidnightIso() {
  const next = new Date();
  next.setHours(24, 0, 0, 0);
  return next.toISOString();
}

function exactHostRegex(hostname) {
  const escaped = String(hostname).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return `^https?://${escaped}(?::[0-9]+)?(?:/|$)`;
}

async function expectedRules(state, protectionSettings, at) {
  const policies = state.policies.filter((policy) => policy.enabled).sort((a, b) => a.id.localeCompare(b.id));
  const active = state.activeSession;
  const activeOpen = !!(active && !Core.clockRolledBack(state, at) && Date.parse(active.deadlineAt) > Date.parse(at));
  const addRules = [];
  for (let index = 0; index < policies.length; index += 1) {
    const policy = policies[index];
    if (activeOpen && active.policyId === policy.id) continue;
    if (!(await permissionFor(policy))) continue;
    addRules.push({
      id: RULE_BASE + index,
      priority: 1,
      action: { type: 'redirect', redirect: { url: gateUrl(policy.id) } },
      condition: {
        regexFilter: exactHostRegex(policy.hostname),
        isUrlFilterCaseSensitive: false,
        resourceTypes: ['main_frame'],
      },
    });
  }
  const canRedirect = await broadProtectionPermission();
  addRules.push(...Protection.buildRules(protectionSettings, ProtectionCatalog, new Date(at), {
    baseId: 30_000,
    blockUrl: canRedirect ? protectionUrl() : '',
  }));
  return addRules;
}

async function expectedRulesets(protectionSettings, at) {
  return Protection.adultRulesets(protectionSettings, new Date(at), { canRedirect: await broadProtectionPermission() }).sort();
}

async function reconcileRules(state, protectionSettings, at) {
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: existing.map(rule => rule.id), addRules: await expectedRules(state, protectionSettings, at) });
  // Bundled adult list (static rulesets): enable exactly the sets the current settings need.
  const wanted = await expectedRulesets(protectionSettings, at);
  const all = Object.values(Protection.ADULT_RULESETS);
  await chrome.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds: wanted, disableRulesetIds: all.filter((id) => !wanted.includes(id)),
  });
}

async function expectedScripts(state) {
  const scripts = [];
  for (const policy of state.policies.filter((item) => item.enabled)) {
    if (!(await permissionFor(policy))) continue;
    scripts.push({
      id: `${SITE_SCRIPT_PREFIX}${policy.id}`,
      matches: Core.hostPatterns(policy.hostname),
      js: ['site-guard.js'],
      runAt: 'document_start',
      persistAcrossSessions: true,
      allFrames: false,
    });
  }
  return scripts;
}

// 0.8.0: Reddit stays open; the guard closes 18+ subreddits/profiles and hides their posts.
// Same conditions as the adult list, and only with all-site access (needed to run on reddit.com).
async function expectedGuardScripts(protectionSettings, at) {
  if (!Protection.redditGuardActive(protectionSettings, new Date(at)) || !(await broadProtectionPermission())) return [];
  return [{ id: REDDIT_GUARD_ID, matches: ['*://*.reddit.com/*'], js: ['reddit-guard.js'], css: ['reddit-guard.css'],
    runAt: 'document_start', persistAcrossSessions: true, allFrames: false }];
}

async function reconcileContentScripts(state, protectionSettings, at) {
  const registered = await chrome.scripting.getRegisteredContentScripts();
  const ours = registered.map((script) => script.id).filter((id) => id.startsWith(SITE_SCRIPT_PREFIX) || id === REDDIT_GUARD_ID);
  if (ours.length) await chrome.scripting.unregisterContentScripts({ ids: ours });
  const scripts = [...await expectedScripts(state), ...await expectedGuardScripts(protectionSettings || await loadProtection(), at || currentIso())];
  if (scripts.length) await chrome.scripting.registerContentScripts(scripts);
}

function testFingerprint(state, protection) {
  return Health.canonical({ policies: state.policies, protection });
}

async function verifiedStatus() {
  const at = currentIso();
  const state = await loadState();
  const protection = await loadProtection();
  const enabled = state.policies.filter(policy => policy.enabled);
  const enforcement = { state: 'unknown', enabledSites: enabled.length, permittedSites: 0, protectionEnabled: protection.enabled };
  try {
    // Read browser state; a configured rule or an installed extension is not a receipt.
    for (const policy of enabled) {
      if (await chrome.permissions.contains({ origins: Core.hostPatterns(policy.hostname) })) enforcement.permittedSites += 1;
    }
    const broad = await chrome.permissions.contains({ origins: ['http://*/*', 'https://*/*'] });
    if (enforcement.permittedSites !== enabled.length || (protection.enabled && !broad)) enforcement.state = 'permission_removed';
    else {
      const rules = await chrome.declarativeNetRequest.getDynamicRules();
      const registeredScripts = await chrome.scripting.getRegisteredContentScripts();
      const scripts = registeredScripts.filter(script => script.id.startsWith(SITE_SCRIPT_PREFIX));
      const guards = registeredScripts.filter(script => script.id === REDDIT_GUARD_ID);
      const rulesets = (await chrome.declarativeNetRequest.getEnabledRulesets()).slice().sort();
      const applied = Health.sameRules(rules, await expectedRules(state, protection, at))
        && Health.sameScripts(scripts, await expectedScripts(state))
        && Health.sameScripts(guards, await expectedGuardScripts(protection, at))
        && JSON.stringify(rulesets) === JSON.stringify(await expectedRulesets(protection, at));
      enforcement.state = !applied ? 'unknown' : enabled.length || protection.enabled ? 'active' : 'not_configured';
    }
  } catch { /* Keep unknown when a browser API cannot confirm the current state. */ }
  const record = (await chrome.storage.local.get(SELF_TEST_KEY))[SELF_TEST_KEY];
  return { ...Core.publicStatus(state, at), checkedAt: at, enforcement,
    selfTest: Health.publicTest(record, Core.VERSION, at, testFingerprint(state, protection)) };
}

async function startBoundaryTest(policyId) {
  const state = await loadState();
  const protection = await loadProtection();
  const at = currentIso();
  const previous = (await chrome.storage.local.get(SELF_TEST_KEY))[SELF_TEST_KEY];
  const fingerprint = testFingerprint(state, protection);
  if (Health.publicTest(previous, Core.VERSION, at, fingerprint).state === 'pending') return { ok: true, pending: true };
  const policy = state.policies.find(item => item.enabled && (!policyId || item.id === policyId));
  if (!policy) return { ok: false, error: 'test_site_required' };
  if (!(await permissionFor(policy))) return { ok: false, error: 'permission_required' };
  const blocked = Protection.decision(protection, ProtectionCatalog, policy.homeUrl, new Date(at)).blocked;
  if (!blocked && Core.accessDecision(state, policy.homeUrl, at).allowed) return { ok: false, error: 'test_window_active' };
  if ((await verifiedStatus()).enforcement.state !== 'active') return { ok: false, error: 'enforcement_failed' };
  const tab = await chrome.tabs.create({ url: 'about:blank' });
  const record = { state: 'pending', startedAt: at, checkedAt: null, version: Core.VERSION,
    fingerprint, tabId: tab.id, policyId: policy.id, page: blocked ? 'block.html' : `gate.html?site=${encodeURIComponent(policy.id)}` };
  try {
    // Persist before navigation so document_start, worker sleep and a fast redirect cannot race the receipt.
    await chrome.storage.local.set({ [SELF_TEST_KEY]: record });
    await chrome.tabs.update(tab.id, { url: policy.homeUrl });
    return { ok: true, pending: true };
  } catch {
    await chrome.storage.local.set({ [SELF_TEST_KEY]: { ...record, state: 'failed', checkedAt: currentIso() } }).catch(() => undefined);
    await chrome.tabs.remove(tab.id).catch(() => undefined);
    return { ok: false, error: 'test_failed' };
  }
}

async function confirmBoundaryTest(sender) {
  const record = (await chrome.storage.local.get(SELF_TEST_KEY))[SELF_TEST_KEY];
  if (!record || record.state !== 'pending' || sender.frameId !== 0 || !sender.tab || sender.tab.id !== record.tabId) return { ok: true, confirmed: false };
  const candidates = [sender.url, sender.documentUrl, sender.tab.url];
  if (!candidates.includes(chrome.runtime.getURL(record.page))) return { ok: true, confirmed: false };
  const status = await verifiedStatus();
  if (status.selfTest.state !== 'pending' || status.enforcement.state !== 'active') return { ok: true, confirmed: false };
  const receipt = { ...record, state: 'passed', checkedAt: currentIso() };
  await chrome.storage.local.set({ [SELF_TEST_KEY]: receipt });
  return { ok: true, confirmed: true, checkedAt: receipt.checkedAt };
}

async function scheduleBoundary(state, at) {
  await chrome.alarms.clear(BOUNDARY_ALARM);
  const session = state.activeSession;
  if (!session) return;
  const when = Date.parse(session.deadlineAt);
  if (Number.isFinite(when) && when > Date.parse(at)) await chrome.alarms.create(BOUNDARY_ALARM, { when });
}

async function scheduleProtectionBoundary(settings) {
  await chrome.alarms.clear(PROTECTION_ALARM);
  const next = Protection.nextScheduleBoundary(settings, new Date());
  const when = next ? Date.parse(next) : NaN;
  if (Number.isFinite(when) && when > Date.now()) await chrome.alarms.create(PROTECTION_ALARM, { when });
}

async function redirectDeniedTabs(state, protectionSettings, at) {
  const tabs = await chrome.tabs.query({});
  await Promise.all(tabs.map(async (tab) => {
    if (!tab.id || typeof tab.url !== 'string' || !/^https?:/.test(tab.url)) return;
    const protectionDecision = Protection.decision(protectionSettings, ProtectionCatalog, tab.url, new Date(at));
    if (protectionDecision.blocked) {
      try { await chrome.tabs.update(tab.id, { url: protectionUrl() }); }
      catch { /* A tab may disappear between query and update. */ }
      return;
    }
    const decision = Core.accessDecision(state, tab.url, at);
    if (decision.allowed || !decision.policy) return;
    attemptsByTab.set(tab.id, tab.url);
    try { await chrome.tabs.update(tab.id, { url: gateUrl(decision.policy.id) }); }
    catch { /* A tab may disappear between query and update. */ }
  }));
}

async function updateActionState(state, protectionSettings, at) {
  try {
    const enabled = state.policies.filter((policy) => policy.enabled).length;
    const session = state.activeSession;
    let text = enabled ? String(Math.min(99, enabled)) : 'NEW';
    let color = enabled ? '#087c9d' : '#8a5a14';
    const protection = Protection.summary(protectionSettings, ProtectionCatalog, new Date(at));
    let title = enabled ? `Satoru Attention · ${enabled} site${enabled === 1 ? '' : 's'}` : 'Satoru Attention · setup needed';
    if (protection.enabled) title += ` · protection ${protection.recreationActive ? 'paused' : 'on'}`;
    if (session) {
      const remaining = Date.parse(session.deadlineAt) - Date.parse(at);
      text = remaining > 0 ? 'ON' : '!';
      color = remaining > 0 ? '#13744d' : '#a32f2a';
      title = remaining > 0 ? `Satoru Attention · ${Math.max(1, Math.ceil(remaining / 60000))} min` : 'Satoru Attention · boundary reached';
    }
    await Promise.all([
      chrome.action.setBadgeBackgroundColor({ color }),
      chrome.action.setBadgeText({ text }),
      chrome.action.setTitle({ title }),
    ]);
  } catch { /* Badge visibility is helpful, never part of the enforcement transaction. */ }
}

async function reconcileEnforcement(state, options = {}) {
  const at = currentIso();
  const protectionSettings = options.protectionSettings || await loadProtection();
  await reconcileRules(state, protectionSettings, at);
  await reconcileContentScripts(state, protectionSettings, at);
  await scheduleBoundary(state, at);
  await scheduleProtectionBoundary(protectionSettings);
  await scheduleLockAlarm(protectionSettings);
  if (options.redirectTabs !== false) await redirectDeniedTabs(state, protectionSettings, at);
  await updateActionState(state, protectionSettings, at);
}

async function commitWithEnforcement(previousState, nextState, options = {}) {
  let saved;
  try { saved = await saveState(nextState); }
  catch {
    return { ok: false, error: 'storage_unavailable', committed: false, retryable: true };
  }
  try {
    await reconcileEnforcement(saved, options);
    return { ok: true, state: saved };
  } catch {
    // State and enforcement are one user-visible transaction. Restore the prior
    // snapshot when Chrome rejects a DNR/script/alarm update, then reconstruct it.
    try {
      const restored = await saveState(previousState);
      try {
        await reconcileEnforcement(restored);
        return { ok: false, error: 'enforcement_failed', committed: false, retryable: true };
      } catch {
        await scheduleRecovery();
        return { ok: false, error: 'enforcement_recovery', committed: false, retryable: true };
      }
    } catch {
      // The new snapshot may be committed if storage rollback itself failed. Say
      // that explicitly so the UI refreshes instead of blindly repeating a write.
      await scheduleRecovery();
      return { ok: false, error: 'enforcement_recovery', committed: true, retryable: true };
    }
  }
}

async function commitProtectionWithEnforcement(previousSettings, nextSettings) {
  let saved;
  try { saved = await saveProtection(nextSettings); }
  catch { return { ok: false, error: 'storage_unavailable', committed: false, retryable: true }; }
  try {
    await reconcileEnforcement(await loadState(), { protectionSettings: saved });
    return { ok: true, settings: saved, summary: Protection.summary(saved, ProtectionCatalog, new Date()) };
  } catch {
    try {
      const restored = await saveProtection(previousSettings);
      try {
        await reconcileEnforcement(await loadState(), { protectionSettings: restored });
        return { ok: false, error: 'enforcement_failed', committed: false, retryable: true };
      } catch {
        await scheduleRecovery();
        return { ok: false, error: 'enforcement_recovery', committed: false, retryable: true };
      }
    } catch {
      await scheduleRecovery();
      return { ok: false, error: 'enforcement_recovery', committed: true, retryable: true };
    }
  }
}

function contextFor(state, siteId, at) {
  const requestedPolicy = siteId ? Core.policyById(state, siteId) : null;
  const activePolicy = state.activeSession ? Core.policyById(state, state.activeSession.policyId) : null;
  const policy = (activePolicy && (!siteId || activePolicy.id === siteId) ? activePolicy : null)
    || (requestedPolicy && requestedPolicy.enabled ? requestedPolicy : null)
    || (!siteId ? state.policies.find((item) => item.enabled) : null)
    || null;
  const session = state.activeSession && policy && state.activeSession.policyId === policy.id ? state.activeSession : null;
  const clockRollback = !!(session && Core.clockRolledBack(state, at));
  return {
    ok: true,
    configured: !!policy,
    policy,
    activeSession: session,
    boundary: session ? (clockRollback
      ? { over: true, remainingMs: 0, mode: session.mode, canExtend: false, extensionsLeft: 0, emergencyAvailable: false }
      : Core.boundaryOptions(state, at)) : null,
    emergency: session && !clockRollback ? Core.emergencyStatus(state, at) : null,
    clockRollback,
    resumeUrl: policy ? (session ? missionTarget(null, state, policy, session) : policy.homeUrl) : null,
    quota: policy ? Core.quotaStatus(state, policy.id, at, localDayKey()) : null,
    pendingPolicy: policy ? state.pendingPolicies.find((item) => item.policyId === policy.id) || null : null,
  };
}

function safeAttempt(tabId, state, policy) {
  const attempted = attemptsByTab.get(tabId);
  attemptsByTab.delete(tabId);
  if (!attempted || !policy) return policy ? policy.homeUrl : null;
  const matched = Core.policyForUrl(state, attempted);
  return matched && matched.id === policy.id ? attempted : policy.homeUrl;
}

function missionTarget(tabId, state, policy, session) {
  const attempted = safeAttempt(tabId, state, policy);
  if (!policy || !session) return attempted;
  const origin = `https://${policy.hostname}`;
  if (policy.appKey === 'tiktok') {
    if (session.purpose === 'publish' || session.purpose === 'create') return `${origin}/tiktokstudio/upload?from=webapp`;
    if (session.purpose === 'research' && session.topic) return `${origin}/search?q=${encodeURIComponent(session.topic)}`;
    if (session.purpose === 'watch') return `${origin}/favorites`;
    if (session.purpose === 'reply') return `${origin}/messages`;
  }
  if (policy.appKey === 'youtube') {
    if (session.purpose === 'publish' || session.purpose === 'create') return `${origin}/upload`;
    if (session.purpose === 'research' && session.topic) return `${origin}/results?search_query=${encodeURIComponent(session.topic)}`;
    if (session.purpose === 'watch') {
      try {
        const url = new URL(attempted);
        if (url.hostname === policy.hostname && ['/watch', '/playlist'].includes(url.pathname)) return url.toString();
      } catch { /* Use the finite saved-items fallback below. */ }
      return `${origin}/feed/watch_later`;
    }
  }
  return attempted || policy.homeUrl;
}

async function handleExtensionMessage(message, sender) {
  const type = message && message.type;
  if (type === 'PING') return { ok: true, version: Core.VERSION };
  if (type === 'GET_HEALTH') return serialized(async () => ({ ok: true, status: await verifiedStatus() }));
  if (type === 'START_BOUNDARY_TEST') return serialized(() => startBoundaryTest(message.policyId));
  if (type === 'CONFIRM_BOUNDARY_TEST') return serialized(() => confirmBoundaryTest(sender));
  if (type === 'GET_CONTEXT') {
    const state = await loadState();
    return contextFor(state, message.siteId, currentIso());
  }
  if (type === 'GET_OPTIONS') {
    const state = await loadState();
    const protection = await loadObservedProtection();
    const permissions = {};
    for (const policy of state.policies) permissions[policy.id] = await permissionFor(policy);
    return { ok: true, state, permissions, protection,
      protectionPermission: await broadProtectionPermission(),
      protectionSummary: Protection.summary(protection, ProtectionCatalog, new Date()),
      version: Core.VERSION };
  }
  if (type === 'SAVE_PROTECTION') {
    return serialized(async () => {
      const previous = await loadObservedProtection();
      // The lock is owned here: a page can neither drop nor shorten it.
      const candidate = { ...Protection.normalizeSettings(message.settings), lock: previous.lock };
      if (Protection.lockActive(previous) && Protection.protectionLoosens(previous, candidate)) {
        return { ok: false, error: 'protection_locked', remainingMs: Protection.lockRemainingMs(previous), settings: previous };
      }
      if (candidate.enabled && !(await broadProtectionPermission())) {
        return { ok: false, error: 'protection_permission_required' };
      }
      return commitProtectionWithEnforcement(previous, candidate);
    });
  }
  if (type === 'LOCK_PROTECTION') {
    return serialized(async () => {
      const previous = await loadObservedProtection();
      const result = Protection.startLock(previous, message.days, new Date());
      if (!result.ok) return result;
      return commitProtectionWithEnforcement(previous, result.settings);
    });
  }
  if (type === 'START_SESSION') {
    return serialized(async () => {
      const state = await loadState();
      const id = `session_${crypto.randomUUID().replace(/-/g, '').slice(0, 24)}`;
      const result = Core.startSession(state, { ...message.input, id, dayKey: localDayKey() }, currentIso());
      if (!result.ok) return result;
      const commit = await commitWithEnforcement(state, result.state, { redirectTabs: false });
      if (!commit.ok) return commit;
      const saved = commit.state;
      const policy = Core.policyById(saved, result.session.policyId);
      return { ok: true, session: result.session, targetUrl: missionTarget(sender.tab && sender.tab.id, saved, policy, result.session) };
    });
  }
  if (type === 'EXTEND_SESSION') {
    return serialized(async () => {
      const state = await loadState();
      const result = Core.extendSession(state, currentIso());
      if (!result.ok) return result;
      const commit = await commitWithEnforcement(state, result.state, { redirectTabs: false });
      if (!commit.ok) return commit;
      const saved = commit.state;
      const policy = Core.policyById(saved, result.session.policyId);
      return { ok: true, session: result.session, targetUrl: policy && policy.homeUrl };
    });
  }
  if (type === 'PUZZLE_NEW') {
    return serialized(async () => {
      const state = await loadState();
      const options = Core.boundaryOptions(state, currentIso());
      if (!options || !options.puzzle) return { ok: false, error: 'puzzle_unavailable' };
      const puzzle = PuzzleCore.pick(Puzzles, options.puzzle.tier);
      if (!puzzle) return { ok: false, error: 'puzzle_unavailable' };
      await chrome.storage.session.set({ [PUZZLE_KEY]: { puzzle, ply: 1, sessionId: state.activeSession.id } });
      return { ok: true, puzzle: PuzzleCore.publicStart(puzzle), everyMinutes: options.puzzle.everyMinutes };
    });
  }
  if (type === 'PUZZLE_MOVE') {
    return serialized(async () => {
      const pending = (await chrome.storage.session.get(PUZZLE_KEY))[PUZZLE_KEY];
      const state = await loadState();
      if (!pending || !state.activeSession || pending.sessionId !== state.activeSession.id
        || pending.puzzle.id !== message.id) return { ok: false, error: 'puzzle_unavailable' };
      const verdict = PuzzleCore.checkMove(pending.puzzle, pending.ply, message.uci);
      if (!verdict.ok) return verdict;
      if (!verdict.correct) {
        // One wrong move ends this puzzle; the next one is a different position.
        await chrome.storage.session.remove(PUZZLE_KEY);
        return { ok: true, correct: false, expected: verdict.expected, motif: pending.puzzle.motif || '' };
      }
      if (!verdict.solved) {
        await chrome.storage.session.set({ [PUZZLE_KEY]: { ...pending, ply: verdict.nextPly } });
        return { ok: true, correct: true, reply: verdict.reply, solved: false };
      }
      await chrome.storage.session.remove(PUZZLE_KEY);
      const result = Core.puzzleExtend(state, currentIso());
      if (!result.ok) return result;
      const commit = await commitWithEnforcement(state, result.state, { redirectTabs: false });
      if (!commit.ok) return commit;
      const policy = Core.policyById(commit.state, result.session.policyId);
      return { ok: true, correct: true, solved: true, grantedMinutes: result.grantedMinutes, targetUrl: policy && policy.homeUrl, motif: pending.puzzle.motif || '' };
    });
  }
  if (type === 'FINISH_SESSION') {
    return serialized(async () => {
      const state = await loadState();
      const result = Core.closeSession(state, message.outcome, currentIso());
      if (!result.ok) return result;
      const commit = await commitWithEnforcement(state, result.state);
      if (!commit.ok) return commit;
      const saved = commit.state;
      return { ok: true, episode: result.episode, returnUrl: Core.satoruDeepLink('return', result.episode.appKey) };
    });
  }
  if (type === 'REQUEST_EMERGENCY') {
    return serialized(async () => {
      const state = await loadState();
      const result = Core.requestEmergency(state, currentIso());
      if (!result.ok) return result;
      let saved;
      try { saved = await saveState(result.state); }
      catch { return { ok: false, error: 'storage_unavailable', committed: false, retryable: true }; }
      return { ok: true, emergency: Core.emergencyStatus(saved, currentIso()) };
    });
  }
  if (type === 'GRANT_EMERGENCY') {
    return serialized(async () => {
      const state = await loadState();
      const result = Core.grantEmergency(state, message.reason, currentIso());
      if (!result.ok) return result;
      const commit = await commitWithEnforcement(state, result.state, { redirectTabs: false });
      if (!commit.ok) return commit;
      const saved = commit.state;
      const policy = Core.policyById(saved, result.session.policyId);
      return { ok: true, session: result.session, targetUrl: policy && policy.homeUrl };
    });
  }
  if (type === 'SAVE_POLICY') {
    return serialized(async () => {
      const candidate = Core.cleanPolicy(message.policy);
      if (!candidate) return { ok: false, error: 'policy_invalid' };
      if (!(await permissionFor(candidate))) return { ok: false, error: 'permission_required' };
      const state = await loadState();
      // 0.10.0: the lock covers site boundaries too — no loosening at all while it runs.
      const lockedProtection = await loadObservedProtection();
      const existing = Core.policyById(state, candidate.id);
      if (Protection.lockActive(lockedProtection) && existing && Core.policyLoosens(existing, candidate)) {
        return { ok: false, error: 'protection_locked', remainingMs: Protection.lockRemainingMs(lockedProtection) };
      }
      const result = Core.upsertPolicy(state, candidate, {
        replacePurposes: message.replacePurposes === true,
        deferLoosening: true,
        activatesAt: nextLocalMidnightIso(),
      });
      if (!result.ok) return result;
      const commit = await commitWithEnforcement(state, result.state);
      if (!commit.ok) return commit;
      return { ok: true, policy: result.policy, pending: result.pending === true, activatesAt: result.activatesAt || null };
    });
  }
  if (type === 'TOGGLE_POLICY') {
    return serialized(async () => {
      const state = await loadState();
      const policy = Core.policyById(state, message.policyId);
      if (message.enabled === true && !(await permissionFor(policy))) return { ok: false, error: 'permission_required' };
      const lockedProtection = await loadObservedProtection();
      if (message.enabled !== true && policy && policy.enabled && Protection.lockActive(lockedProtection)) {
        return { ok: false, error: 'protection_locked', remainingMs: Protection.lockRemainingMs(lockedProtection) };
      }
      const result = Core.setPolicyEnabled(state, message.policyId, message.enabled === true, {
        deferLoosening: true,
        activatesAt: nextLocalMidnightIso(),
      });
      if (!result.ok) return result;
      const commit = await commitWithEnforcement(state, result.state);
      if (!commit.ok) return commit;
      return { ok: true, policy: result.policy, pending: result.pending === true, activatesAt: result.activatesAt || null };
    });
  }
  if (type === 'CANCEL_PENDING_POLICY') {
    return serialized(async () => {
      const state = await loadState();
      const result = Core.cancelPendingPolicy(state, message.policyId);
      if (!result.ok) return result;
      const commit = await commitWithEnforcement(state, result.state);
      return commit.ok ? { ok: true } : commit;
    });
  }
  if (type === 'GET_SATORU_LINK') {
    const url = Core.satoruDeepLink(message.action, message.appKey);
    return url ? { ok: true, url } : { ok: false, error: 'link_invalid' };
  }
  if (type === 'OPEN_GATE') {
    const state = await loadState();
    const policy = Core.policyById(state, message.policyId) || state.policies.find((item) => item.enabled);
    if (!policy) return { ok: false, error: 'policy_unavailable' };
    await chrome.tabs.create({ url: gateUrl(policy.id) });
    return { ok: true };
  }
  if (type === 'OPEN_OPTIONS') {
    await chrome.runtime.openOptionsPage();
    return { ok: true };
  }
  return { ok: false, error: 'unknown_message' };
}

async function handleBridgeMessage(message, sender) {
  if (message.type === 'BRIDGE_STATUS') {
    return serialized(async () => ({ ok: true, status: await verifiedStatus() }));
  }
  if (message.type === 'OPEN_OPTIONS') {
    await chrome.runtime.openOptionsPage();
    return { ok: true };
  }
  return { ok: false, error: 'bridge_message_denied' };
}

async function handleSiteMessage(message, sender) {
  let senderOrigin;
  let messageOrigin;
  try {
    senderOrigin = new URL(sender && sender.url).origin;
    messageOrigin = new URL(message && message.url).origin;
  } catch {
    return { ok: false, error: 'sender_invalid' };
  }
  if (!sender.tab || !sender.tab.id || typeof message.url !== 'string' || senderOrigin !== messageOrigin) {
    return { ok: false, error: 'sender_invalid' };
  }
  return serialized(async () => {
    const at = currentIso();
    const state = await observeClockState(at);
    const decision = Core.accessDecision(state, message.url, at);
    if (!decision.allowed && decision.policy) attemptsByTab.set(sender.tab.id, message.url);
    return {
      ok: true,
      allowed: decision.allowed,
      reason: decision.reason,
      remainingMs: decision.remainingMs,
      gateUrl: decision.policy ? gateUrl(decision.policy.id) : null,
    };
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  let work;
  if (message && message.type === 'CHECK_ACCESS') work = handleSiteMessage(message, sender);
  else if (bridgeSender(sender)) work = handleBridgeMessage(message || {}, sender);
  else if (extensionSender(sender)) work = handleExtensionMessage(message || {}, sender);
  else work = Promise.resolve({ ok: false, error: 'sender_denied' });
  work.then(sendResponse).catch((error) => sendResponse({ ok: false, error: 'internal_error', detail: String(error && error.message || error) }));
  return true;
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (![BOUNDARY_ALARM, RECOVERY_ALARM, PROTECTION_ALARM, LOCK_ALARM].includes(alarm.name)) return;
  serialized(async () => {
    const state = await loadState();
    await reconcileEnforcement(state, { protectionSettings: await loadObservedProtection() });
  }).catch(() => undefined);
});

chrome.permissions.onAdded.addListener(() => {
  serialized(async () => reconcileEnforcement(await loadState())).catch(() => undefined);
});

chrome.permissions.onRemoved.addListener(() => {
  serialized(async () => reconcileEnforcement(await loadState())).catch(() => undefined);
});

chrome.runtime.onStartup.addListener(() => {
  serialized(async () => reconcileEnforcement(await loadState())).catch(() => undefined);
});

chrome.runtime.onInstalled.addListener((details) => {
  serialized(async () => {
    const state = await saveState(await loadState());
    await saveProtection(await loadProtection());
    await reconcileEnforcement(state);
    if (details.reason === 'install') await chrome.runtime.openOptionsPage();
  }).catch(() => undefined);
});
